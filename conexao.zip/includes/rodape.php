<div class="container footer">
      <footer class="row row-cols-1 row-cols-sm-2 row-cols-md-5 py-5 my-5 border-top">
        <div class="col mb-4" id="imgRodaPeCenter">
          <a href="/" class="d-flex align-items-center mb-3 link-dark text-decoration-none">
            <img class="img-logoFooter " id="imgRodaPe" src="imagens/logo-cacador-de-preco.png" alt="Caçador de Preço" srcset="">
          </a>      
        </div>
        <div class="col mb-2">
        </div>
        <div class="col mb-3">
          <h5>De seu interesse </h5>
          <ul class="nav flex-column">
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Procurar por produtos</a></li>
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Promoções</a></li>
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Melhores Orfertas</a></li>
          </ul>
        </div>
        <div class="col mb-3">
          <h5>Produtos</h5>
          <ul class="nav flex-column">
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Página inicial</a></li>
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Cadastro</a></li>
            <li class="nav-item mb-2"><a href="telaLogin.php" class="nav-link p-0 text-muted">Login</a></li>
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Política de Privacidade</a></li>
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Sobre Nós</a></li>
          </ul>
        </div>
        <div class="col mb-3">
          <h5>Redes Sociais</h5>
          <ul class="nav flex-column">
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Facebook</a></li>
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Instagram</a></li>
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Twitter</a></li>
            <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Youtube</a></li>
          </ul>
        </div>
    </footer>
  </div>
  <script src="https://kit.fontawesome.com/adf9b248e1.js" crossorigin="anonymous"></script>